/*! \file devicelink.cpp
	\brief The main source file for the devicelink functions. v2.0.5
*/

#include "devicelink.h"

/*
	This variable will be used for providing a thread locking mechanism and is
	used throughout the class, hence it being global.
*/
MC_CritSection my_critsec;

/// Constructor. Mainly initializes the private member variables.
C_DeviceLink::C_DeviceLink()
{
	memset(m_cmd, NULL, sizeof(m_cmd));
	memset(m_buff, NULL, sizeof(m_buff));
	m_port = 0;
	m_code_len = 0;
	m_initialized = FALSE;
	m_readdata = FALSE;
	dl_strncpy(m_game_ip,"0.0.0.0",sizeof(m_game_ip));
	memset(m_dl_ver, NULL, sizeof(m_dl_ver));
	dl_output = NULL;
	m_sock = 0;
	for (int i = 0; i < 4; ++i)
	{
		m_engine[i].rpm = 0;
		m_engine[i].manifold = 0.00;
		m_engine[i].temp_oilin = 0.00;
		m_engine[i].temp_oilout = 0.00;
		m_engine[i].temp_water = 0.00;
		m_engine[i].temp_cylinders = 0.00;
	}
}

/*! \brief Deconstructor...
*/
C_DeviceLink::~C_DeviceLink()
{

}

/*! \brief This function allows a developer to set the command buffer

This method takes in a string which is checked for NULL or if it is 
larger than the private member variable it will bail.
Ultimately, it will assign the private m_cmd variable with a 
string to be sent to the game. It doesn't actually send the code
just preps the buffer to be sent.

*/
bool C_DeviceLink::set_command_buff(const char * code)
{
	if (code == NULL)
	{
		errmsg("Invalid code passed to set_command_buff.\n");
		return FALSE;
	}
	if (m_code_len > sizeof(m_cmd))
	{
		errmsg("temp buffer too large for m_cmd in set_command_buff.\n");
		return FALSE;
	}
	MC_Lock m_Lock(&my_critsec);
#if _MSC_VER >= 1400
	_snprintf_s(m_cmd,sizeof(m_cmd),_TRUNCATE,"%c%c%s",REQUEST,DELIM_1,code);
#else
	_snprintf(m_cmd,sizeof(m_cmd),"%c%c%s",REQUEST,DELIM_1,code);
#endif
	return TRUE;
}

/*! This routine converts the contents of m_buff into a true float.

It takes the devicelink code of the of the particular function as a parameter.
Look in the devicelink.h for the defined codes.

*/
float C_DeviceLink::getfloatval(const char* code)
{
	float val = 0.00;

	//make sure it's a response code
	char temp_buff[80];
	memset(temp_buff, NULL, sizeof(temp_buff));
	get_read_buff(temp_buff, sizeof(temp_buff));
	
	if(temp_buff[0] != ANSWER)
	{
		errmsg("Not a valid response code in buffer!\n");
		val = -1;
		return val;
	}

	//null out temp and call getparamval
	//to set temp equal to the string representation
	//of returned val. We then convert it to a float

	char temp[32];
	memset(temp, NULL, sizeof(temp));
	
	if (getparamval(code, temp, sizeof(temp)) == TRUE)
	{
#if _MSC_VER >= 1400
		if (sscanf_s(temp,"%f", &val,sizeof(temp)) == EOF)
#else
		if (sscanf(temp,"%f", &val,sizeof(temp)) == EOF)
#endif
		{
			//Bail if sscanf did no conversion.
			errmsg("getfloatval had a problem converting temp into val.\n");
			val = -1;
		}
		return val;
	}	
	errmsg("getparamval returned FALSE in getfloatval.\n");
	val = -1;
	return val;
}
/*! \brief This private routine does an actual query to the devicelink server for a float value.

It takes the devicelink code as a param, queries the game and converts the resulting code
into a true float value.

*/
float C_DeviceLink::queryfloat(const char *code)
{
	if (QueryMsg(code) == TRUE)
	{
		float var = 0.00;
		var = getfloatval(code);
		if (var <= 0.00)
		{
			errmsg("getfloatval returned a error.\n");
		}
		return var;
	} else
	{
		errmsg("QueryMsg returned FALSE in queryfloat\n");
		if (HasData() == FALSE)
		{
			errmsg("queryfloat: Query failed to read data from socket.\n");
		}
		return -1.00;
	}

}

/*! \brief Gets a string representation of the return value from the queried code and places it in the passed qstr. 

\warning Calling function is responsible for allocating memory for qstr.

*/
bool C_DeviceLink::querystring(const char* code, char* qstr, unsigned int buff_size)
{
	if (QueryMsg(code) == TRUE)
	{
		if (getparamval(code, qstr, buff_size) == TRUE)
		{
			return TRUE;
		}
	} else
	{
		errmsg("QueryMsg returned FALSE in querystring\n");
		if (HasData() == FALSE)
		{
			errmsg("Query failed to read data from socket.\n");
		}
		return FALSE;
	}
	
	return FALSE;
}

/*! \brief This private routine that returns the value of the paramter returned in an A coded response from the server.

	The result is stored in the buffer pointed to by strval.
	\warning strval must be allocated by the calling function!
*/
bool C_DeviceLink::getparamval(const char *code, char* strval, unsigned int buff_size)
{
	//make sure it's a response code
	char temp_buff[80];
	memset(temp_buff, NULL, sizeof(temp_buff));
	buff_size = sizeof(temp_buff);
	get_read_buff(temp_buff, buff_size);
	if(temp_buff[0] != ANSWER)
	{
		errmsg("getparamval: m_buff contains invalid response code.\n");
		return FALSE;
	}
	
	//null out token and set pdest to point at the part of the temp_buff
	//that contains the result from a query. i.e if code 80 was passed
	//in we look for code 80 in "A/80\0.35" and then grab the 0.35 
	char* token = NULL;
	token = strstr(temp_buff, code);
	
	//Parse to the first delimiter for the code. We don't care about it.
	
	//setting up a max amount to step through so we don't walk off the end of the buffer.
	unsigned int sz = strlen(token); 
	unsigned int cnt = 0;
	while ((token[0] != DELIM_2) & (token[0] != NULL) & (cnt <= sz))
	{
		++token;
		++cnt;
	}

	++token; //step one more time to point to the first non-delimiting character.

	if (token == NULL)
	{
		errmsg("getparamval: cannot find value delimiter in return code.\n");
		return FALSE;
	}	
	//Now get the param value.
	unsigned int j = 0;
	sz = strlen(token);
	char * ptr = NULL;
	ptr = strval;
	//copying the data to strval for conversion. Why didn't I use strcpy or some variant?
	//well, because in 1C's infinite wisdom they chose to use / and \ as delimiters. Since
	//some data can render an unescaped series of tokens with \0 that renders most of the
	//string functions useless.
	while ((token[0] != DELIM_2) & (token[0] != NULL) & (token[0] != DELIM_1) & (j <= sz))
	{
		//strval[j] = token[0];
		*ptr = *token;
		++ptr;
		++token;
		++j;
	}
	
	if (strval != NULL)
	{
		if (strlen(strval) > 0)
		{
			return TRUE;
		}
	}

	return FALSE;
}


/*! \brief Executes a query expecting an int return.

Returns -1 for error and int val if success.  Error conditions are
reached when either getintval fails or the socket has no data in the buffer
from the query.

*/
int C_DeviceLink::queryint(const char *code)
{
	if (QueryMsg(code) == TRUE)
	{
		int var = 0;
		var = getintval(code);
		if (var <= 0)
		{
			errmsg("getinval returned error in queryint.\n");
			var = -1;
		}
		return var;
	} else
	{
		errmsg("QueryMsg returned FALSE in queryint\n");
		if (HasData() == FALSE)
		{
			errmsg("Query failed to read data from socket.\n");
		}
		return -1;
	}
}

/*! \brief Converts the parameter returned by getparamval into an int.

This routine reads the internal buffer (m_buff), parses out the requested matching integer result,
converts it from string value into a true integer value and returns that int to the calling routine.

*/
int C_DeviceLink::getintval(const char *code)
{
	//make sure it's a response code
	char temp_buff[80];
	memset(temp_buff, NULL, sizeof(temp_buff));
	get_read_buff(temp_buff, sizeof(temp_buff));
	int val = 0;
	if(temp_buff[0] != ANSWER)
	{
		val = - 1;
		return val;
	}

	//null out temp and call getparamval
	//to set temp equal to the string representation
	//of returned val. We then convert it to a float

	char temp[64];
	memset(temp, NULL, sizeof(temp));
	
	if (getparamval(code, temp, sizeof(temp)) == TRUE)
	{
		int err = 0;
#if _MSC_VER >= 1400
		err = sscanf_s(temp,"%d", &val, sizeof(temp));
#else
		err = sscanf(temp,"%d", &val, sizeof(temp));
#endif
		if ((err == 0) | (err == EOF))
		{
			errmsg("conversion error in getintval.\n");
			val = -1;
		}
		return val;
	}	
	errmsg("getparamval returned FALSE in getintval.\n");
	val = -1;
	return val;
}


/*! \brief This routine is used as a generic routine for flipping a toggle switch.

It assummes the calling routine passes the correct code. It checks to make sure the interface 
has been initialized and sends the simplified code.  Only error conditions it should have are
either IsInitialized() fails, or a failed SendMsg() call.

*/
bool C_DeviceLink::toggleswitch(const char* code)
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return FALSE;
	}

	set_command_buff(code);
	if (SendMsg()== TRUE)
	{
		return TRUE;
	} else
	{
		return FALSE;
	}
	
}
/*! \brief Overload for Init(FILE *output) with no file pointer passed in. Just calls Init with a NULL.

*/
bool C_DeviceLink::Init()
{
	return Init(NULL);
}

/*! \brief Initialize the DeviceLink object. 

IP and port are read from a config.ini file incoming parameter is the 
debug output file. defaults to stderr. DEBUG_OUTPUT must be defined for 
messages to be written.  This is the first method to call when using this library.
It abstracts out the network code for setting up a UDP client and only needs the
config file with the IP address and port number of the server.

If Init is called with a FILE parameter and DEBUG_OUTPUT has been defined then
it will output the debug and error messages 

*/
bool C_DeviceLink::Init(FILE *output)
{
	//if the calling program passed in file name then log
	//to that file. Otherwise log to the console.
	if (output == NULL)
	{
		dl_output = stderr;
	} else
	{
		dl_output = output;
	}

	if (ReadConfig() == FALSE)
	{
		errmsg("Failed to read config file\n");
		m_initialized = FALSE;
		return FALSE;
	}
	
	//setup the UDP client 
	m_this_end.sin_port=htons(0);
	m_this_end.sin_addr.s_addr=htons(INADDR_ANY);
	m_this_end.sin_family=AF_INET;
	memset(&m_this_end.sin_zero, 0, sizeof(m_this_end.sin_zero));
	m_other_end.sin_port = htons(m_port);
	m_other_end.sin_addr.s_addr = inet_addr(m_game_ip);
	m_other_end.sin_family = AF_INET;
	memset(&m_other_end.sin_zero, 0, sizeof(m_other_end.sin_zero));
	WSADATA wsaData;
	
	//yeah, I know, MFC code but this was easier than rolling my own.
	//would have preferred to make this multi-platform. maybe a later
	//version.
	int retval = 0;
	retval = WSAStartup(0x202,&wsaData);

	if (retval != 0) 
	{
#ifdef DEBUG_OUTPUT
		fprintf(output,"WSAStartup failed with error %d\n",retval);
#endif
        WSACleanup();
        return FALSE;
    }

	//create the UDP socket.
	m_sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if (m_sock == INVALID_SOCKET)
	{
#ifdef DEBUG_OUTPUT
		fprintf(dl_output,"Error in socket call in Init(). Error :%d\n", WSAGetLastError());
#endif
		WSACleanup();
		return FALSE;
	}
#pragma warning( push, 3 ) //Microsoft's FD_SET macro causes a Lvl 4 warning. Choosing to ignore it.
	FD_SET(m_sock, &SelectReadFds);
#pragma warning( pop ) // pop back to lvl 4 warning.
	//bail if socket creation fails
	if (m_sock < 0)
	{
#ifdef DEBUG_OUTPUT
		fprintf(dl_output,"Client: Error Opening socket: Error %d\n",WSAGetLastError());
#endif
        WSACleanup();
		return FALSE;
	} 
	
	//bind the socket. bail if fails	
	if (bind(m_sock, reinterpret_cast<struct sockaddr*>(&m_this_end), sizeof(m_this_end)) == SOCKET_ERROR)
    {
#ifdef DEBUG_OUTPUT
		fprintf(dl_output,"Client: Error binding socket: Error %d\n",WSAGetLastError());
#endif
        WSACleanup();
		return FALSE;
	} 

	if ( connect( m_sock, reinterpret_cast<struct sockaddr*>(&m_other_end), sizeof(m_other_end) ) == SOCKET_ERROR)
	{
#ifdef DEBUG_OUTPUT
		fprintf(dl_output,"Failed to connect. Error %d\n",WSAGetLastError());
#endif
		WSACleanup();
		return FALSE;
	}

	m_initialized = TRUE;
	return TRUE;
}

/*! \brief Send the string stored in m_buff to the game server. 

Started to make this method private but opted to keep it public so that any command/query string could be 
built and use this method to transmit.  It will fail on IsInitialized() fail or socket error.

*/
bool C_DeviceLink::SendMsg()
{	
	if (IsInitialized() == FALSE)
	{
		init_err();
		return FALSE;
	}

	int err = 0;
	char temp_cmd[64];
	memset(temp_cmd, NULL,sizeof(temp_cmd));
	get_cmd_buff(temp_cmd, sizeof(temp_cmd));
	int len = static_cast<int>(strlen(temp_cmd));
	err = send(m_sock, temp_cmd, len, 0);
	if (err == SOCKET_ERROR)
	{
#ifdef DEBUG_OUTPUT
		fprintf(dl_output, "error in SendMSg. Error %d\n",WSAGetLastError());
#endif
		return FALSE;
	}
	
	return TRUE;
}

/*! \brief Read response to the query and store it in the private m_buff. 

This fails if IsInitialized() fails and on socket error.  If it succeeds
it calls set_has_read_data(bool flag) to set the HasData() properly. It also
loads the in the internal m_buff with the data read from the socket via the 
set_read_buff(char* temp_buff) function.
\warning Calling routine must parse out the buffer for actual values.  

*/

bool C_DeviceLink::ReadMsg()
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return FALSE;
	}
	size_t len = 0;
	int buff_len = 0;
	char temp_buff[80];
	memset(temp_buff, NULL, sizeof(temp_buff));
	buff_len = sizeof(temp_buff);
	len = recv(m_sock, temp_buff, buff_len, 0);
	temp_buff[len] = '\0';
	buff_len = strlen(temp_buff);
	if ((set_read_buff(temp_buff, buff_len) == FALSE) | (buff_len == 0) | (len == SOCKET_ERROR))
	{
		errmsg("set_read_buff returned FALSE in ReadMsg,\nor no data was read from the socket");
		set_has_read_data(FALSE);
		return FALSE;
	}
	set_has_read_data(TRUE);
	return TRUE;
}

/*! \brief Returns true if the gear is already up and false if it isn't.

Fails if queryfloat(char* code) or IsInitialized() fails or the gear is actually up.

*/
bool C_DeviceLink::Gear_Is_Up()
{
	if (IsInitialized()== FALSE)
	{
		init_err();
		return FALSE;
	}
	
	float val = 0.00;
	{
	MC_Lock m_Lock(&my_critsec);
	m_code_len = strlen(DL_GET_GEAR_STATUS);
	} //scope ender to force thread lock to deconstruct
	val = queryfloat(DL_GET_GEAR_STATUS);
	if (val > 0.00)
	{
		return FALSE;
	} else if (val < 0.00)
	{
		errmsg("queryfloat returned an error. -1 was returned.\n");
		return FALSE; 
	} else
	{
		errmsg("Gear already up in Gear_Is_Up\n");
		return TRUE;		
	}
}

/*! \brief Toggles the state of the landing gear

Toggles the gear setting and utilizes the toggleswitch(char* code) function.

*/
bool C_DeviceLink::ToggleGear()
{	
	{
	MC_Lock m_Lock(&my_critsec);
	m_code_len = strlen(DL_SET_GEAR_STATUS);
	} //scope ender to force thread lock to deconstruct

	if (toggleswitch(DL_SET_GEAR_STATUS) == TRUE)
	{
		return TRUE;
	}
	return FALSE;
}

/*! \brief Sets the landing gear to be up.

Only fails when IsIntialized() fails. Executes ToggleGear()
if Gear_Is_Up() returns a false.  

*/
bool C_DeviceLink::SetGearUp()
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return FALSE;
	}

	if (Gear_Is_Up() == TRUE)
	{
		errmsg("Gear already up in SetGearUp\n");
	} else
	{
		ToggleGear();
	}
	return TRUE;
}

/*! \brief Sets the gear to be down

Only fails when IsIntialized() fails. Executes ToggleGear()
if Gear_Is_Up() returns a true.  

*/
bool C_DeviceLink::SetGearDown()
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return FALSE;
	}

	if (Gear_Is_Up() == TRUE)
	{
		ToggleGear();
	} else
	{
		errmsg("Gear already down in SetGearDown\n");
	}
	return TRUE;
}

/*! \brief Takes the passed in code for querying a gear position and returns a float.

This is for checking each individual wheel versus just an overall status. 
Return of -1 means an error occurred in either IsInitialized() or queryfloat(char* code).

*/

float C_DeviceLink::GetGearPos(char* gearcode)
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return -1;
	}
	
	float gearpos = 0.00;
	gearpos = queryfloat(gearcode);
	if (gearpos >= 0.00)
	{
		return gearpos;
	}
	errmsg("GetGearPos:queryfloat returned a -1 to GetGearPos\n");
	return -1;
}


/*! \brief This reads in the config.ini file.

I'm likely to rewrite this in the future. It's been written piecemeal 
so it's sloppy. It reads the config.ini file for the settings.

*/

bool C_DeviceLink::ReadConfig()
{
#if _MSC_VER >= 1400
	FILE *fp = NULL;
	errno_t err = 0;
	err = fopen_s(&fp, "config.ini", "r");
	if (err != 0)
	{
		errmsg("Cannot open config file.\n");
		exit(1);
	}
#else
	FILE *fp = NULL;
	fp = fopen("config.ini", "r");
	if (fp == NULL)
	{
		errmsg("Cannot open config file.\n");
		exit(1);
	}
#endif
	char temp[80];
	memset(temp, NULL, sizeof(temp));
	fgets(temp, 19,fp);
	if (temp[1] != 'D')
	{
		errmsg("Invalid config file\n");
		fclose(fp);
		return FALSE;
	}

	fgets(temp, 19, fp);
	if (temp[0] == 'P')
	{
		char* pdest = strstr(temp,"=") + 1;
		if (pdest == NULL)
		{
			errmsg("Invalid IP address in config file.\n");
			fclose(fp);
			return FALSE;
		}
		int err = 0;
#if _MSC_VER >= 1400
		err = sscanf_s(pdest, "%d", &m_port,sizeof(pdest));
#else
		err = sscanf(pdest, "%d", &m_port,sizeof(pdest));
#endif
		if ((err == 0) | (err == EOF))
		{
			errmsg("Invalid port number in config file.\n");
			fclose(fp);
			return FALSE;
		}
	} else
	{
		errmsg("Invalid config file\n");
		fclose(fp);
		return FALSE;
	}

	fgets(temp,19,fp);
	if (temp[0] == 'I')
	{
		char* pdest = strstr(temp,"=") + 1;
		if (pdest == NULL)
		{
			errmsg("Invalid IP address in config file.\n");
			fclose(fp);
			return FALSE;
		}
		int err = 0;
#if _MSC_VER >= 1400
		err = sscanf_s(pdest, "%s", &m_game_ip,sizeof(m_game_ip));
#else
		err = sscanf(pdest, "%s", &m_game_ip,sizeof(m_game_ip));
#endif
		if ((err == 0) | (err == EOF))
		{
			errmsg("Invalid IP address in config file.\n");
			fclose(fp);
			return FALSE;
		}
	} else
	{
		errmsg("Invalid config file\n");
		fclose(fp);
		return FALSE;
	}	

	fclose(fp);
	return TRUE;
}

/*! \brief Returns the Initialized state in a bool. Utilizes MC_Lock for thread safety.

*/
bool C_DeviceLink::IsInitialized()
{
	MC_Lock m_Lock(&my_critsec);
	return m_initialized;
}


/*! \brief This is the public method for querying the devicelink server and reading a response.

It takes the string passed in by code and calls SendMsg() to send the 'R' query and then a ReadMsg()
to get the response. m_code_len MUST be set prior to calling.

*/
bool C_DeviceLink::QueryMsg(const char* code)
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return FALSE;
	}
	if (m_code_len <= 0)
	{
		errmsg("m_code_len not properly set before calling QueryMsg\n");
		return FALSE;
	}
	//send the query string and read the subsequent response.
	set_command_buff(code);  
	if (SendMsg() == TRUE)
	{
		if(ReadMsg() == TRUE)
		{
			if (HasData() == TRUE)
			{
				char temp_buff[80];
				memset(temp_buff, NULL, sizeof(temp_buff));
				if ((get_read_buff(temp_buff, sizeof(temp_buff)) == FALSE))
				{
					errmsg("get_read_buff returned FALSE in QueryMsg\n");
					return FALSE;
				}
/*
				char* pdest == NULL;
				pdest = strstr(temp_buff, code);

				//why this loop? Well, I discovered in the course of testing this library
				//that on occasion the game will either not respond to a query or double up responses
				//or worse, send the responses out of order.  Seems to be more of a network timing 
				//issue more than anything (gotta love UDP!).  Anyhow, this loop parses through the 
				//buffer until it finds a
				//reponse matching its last sent command or the end of the buffer.
				while ((pdest == NULL) & (strlen(temp_buff) != 0))
				{
					errmsg("Query and Response String do not match\n");
					ReadMsg();
					pdest = strstr(temp_buff, code);
				}
*/
				return TRUE;
			} else
			{
				errmsg("No data read from socket. Server may not be up\n");
				return FALSE;
			}
		} else
		{
			errmsg("Read failed. No data read from socket. Server may not be up\n");
			return FALSE;
		}
	} else
	{	
		errmsg("Catastrophic socket failure. SendMsg failed.\n");
		set_has_read_data(FALSE);
		return FALSE;
		}

}

/*! \brief Return a flag status set when data has actually been received from the game.

*/
bool C_DeviceLink::HasData()
{
	MC_Lock m_Lock(&my_critsec);
	return m_readdata;
}

/*! \brief Get the version of DeviceLink you are running from the game.


\warning verstr must be allocated by calling routine and must be at least 64 bytes!
\warning buff_size must be passed in and be sizeof(verstr) in calling routine!

*/
bool C_DeviceLink::GetDLVersion(char* verstr, unsigned int buff_size)
{

	if (IsInitialized() == FALSE)
	{
		init_err();
		return FALSE;
	}	

	if (buff_size < sizeof(m_dl_ver))
	{
		errmsg("Calling routine allocated insuffcient buffer. Must be at least 64 bytes!\n");
		return FALSE;
	}
	{
	MC_Lock m_Lock(&my_critsec);
	m_code_len = strlen(DL_GET_VERSION);
	}
	if (querystring(DL_GET_VERSION, m_dl_ver, sizeof(m_dl_ver)) == TRUE)
	{
		dl_strncpy(verstr, m_dl_ver, buff_size);
		return TRUE;
	}
	errmsg("querystring returned FALSE to GetDLVersion.\n");
	return FALSE;
}


/*! \brief Verifies that a Get command exists for the associated code.

*/
bool C_DeviceLink::ValidGet(const char* code)
{
	char newcode[64];
	char temp[64];
	memset(temp, NULL,sizeof(temp));
	memset(newcode, NULL,sizeof(newcode));
#if _MSC_VER >= 1400
	_snprintf_s(newcode,sizeof(newcode),_TRUNCATE,"%s\\%s",DL_ACCESS_GET,code);
#else
	_snprintf(newcode,sizeof(newcode),"%s\\%s",DL_ACCESS_GET,code);
#endif

	{
	MC_Lock m_Lock(&my_critsec);
	m_code_len = strlen(newcode);
	}
	if (querystring(newcode, temp, sizeof(temp)) == TRUE)
	{
		return TRUE;
	}
	return FALSE;
}


/*! \brief Get the Time of Day

Returns either the TOD in a float value or a -1 as an error.

*/
float C_DeviceLink::GetTOD()
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return -1.00;
	}
	
	float tod = 0.00;
	{
	MC_Lock m_Lock(&my_critsec);
	m_code_len = strlen(DL_TOD);
	} //scope ender to force thread lock to deconstruct
	tod = queryfloat(DL_TOD);

	if (tod >= 0.00)
	{
		return tod;
	}
		errmsg("queryfloat returned a -1 to GetTOD\n");
		return -1.00;
}

/*! \brief Get the ID of the aircraft. 

\warning Calling routine must allocate memory for ac.

*/
bool C_DeviceLink::GetAircraftID(char *ac, unsigned int buff_size)
{	
	if (IsInitialized() == FALSE)
	{
		init_err();
		return FALSE;
	}
	
	char temp[32];
	memset(temp, NULL, sizeof(temp));
	if (buff_size < sizeof(temp))
	{	
		errmsg("Insuffcient buffer allocated for aircraft type name.  Must be at least 32 bytes.\n");
		return FALSE;
	}
	{
	MC_Lock m_Lock(&my_critsec);
	m_code_len = strlen(DL_GET_PLANE);
	}
	if (querystring(DL_GET_PLANE, temp, buff_size) == TRUE)
	{
		//copy temp into the buffer pointed to by ac but let's be safe and
		//do a sanity check on ac while we are at it.
		dl_strncpy(ac, temp, buff_size);
		/*
		for (int i=0; ((i < sizeof(temp)) | (temp[i] != NULL)); ++i)
		{
			ac[i] = temp[i];
		} */
		return TRUE;
	}
	return FALSE;
}

/*! \brief Toggle the state of the Nav lights.

Uses toggleswitch(const char* code)

*/
bool C_DeviceLink::ToggleNavLights()
{
	{
	MC_Lock m_Lock(&my_critsec);
	m_code_len = strlen(DL_TOGGLE_NAV_LTS);
	} //scope ender to force thread lock to deconstruct
	if (toggleswitch(DL_TOGGLE_NAV_LTS) == TRUE)
	{
		return TRUE;
	}
	return FALSE;
}

/*! \brief Toggle the state of the Panel lights

Uses toggleswitch(const char* code)

*/
bool C_DeviceLink::ToggleCockpitLights()
{
	{
	MC_Lock m_Lock(&my_critsec);
	m_code_len = strlen(DL_TOGGLE_COCKPIT_LTS);
	} //scope ender to force thread lock to deconstruct
	if (toggleswitch(DL_TOGGLE_COCKPIT_LTS) == TRUE)
	{
		return TRUE;
	}
	return FALSE;
}
/*! \brief Toggle the state of the landing lights

Uses toggleswitch(const char* code)

*/
bool C_DeviceLink::ToggleLandLights()
{
	{
	MC_Lock m_Lock(&my_critsec);
	m_code_len = strlen(DL_TOGGLE_LND_LTS);
	} //scope ender to force thread lock to deconstruct
	if (toggleswitch(DL_TOGGLE_LND_LTS) == TRUE)
	{
		return TRUE;
	}
	return FALSE;
}

/*! \brief Toggle the wingtip smoke

Uses toggleswitch(const char* code)

*/
bool C_DeviceLink::ToggleSmoke()
{	
	{
	MC_Lock m_Lock(&my_critsec);
	m_code_len = strlen(DL_TOGGLE_SMOKE);
	} //scope ender to force thread lock to deconstruct
	if (toggleswitch(DL_TOGGLE_SMOKE) == TRUE)
	{
		return TRUE;
	}
	return FALSE;
}

/*! \brief private function for starting the passed in engine

Calls SendMsg() and IsInitialized()

*/
bool C_DeviceLink::starteng(const char* seleng, const char* togeng)
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return FALSE;
	}
	char temp_cmd[64];
	memset(temp_cmd, NULL,sizeof(temp_cmd));
#if _MSC_VER >= 1400
	_snprintf_s(temp_cmd,sizeof(temp_cmd),_TRUNCATE,"%s/%s/%s",seleng,togeng,DL_SELECT_ENG_ALL);
#else
	_snprintf(temp_cmd,sizeof(temp_cmd),"%s/%s/%s",seleng,togeng,DL_SELECT_ENG_ALL);
#endif
	{
	MC_Lock m_Lock(&my_critsec);
	m_code_len = strlen(temp_cmd);
	}
	set_command_buff(temp_cmd);

	if (SendMsg() == TRUE)
	{
		return TRUE;
	} else
	{
		return FALSE;
	}
}

/*! \brief Start Engine one. Actually, it selects the engine, toggles it, then selects all.

*/
bool C_DeviceLink::StartEng1()
{
	if (starteng(DL_SELECT_ENG_1,DL_TOGGLE_ENGINE1) == TRUE)
	{
		return TRUE;
	} else
	{
		return FALSE;
	}
}

/*! \brief Start Engine two. Actually, it selects the engine, toggles it, then selects all.

*/
bool C_DeviceLink::StartEng2()
{
	if (starteng(DL_SELECT_ENG_2,DL_TOGGLE_ENGINE2) == TRUE)
	{
		return TRUE;
	} else
	{
		return FALSE;
	}
}
/*! \brief Start Engine three. Actually, it selects the engine, toggles it, then selects all.

*/
bool C_DeviceLink::StartEng3()
{
	if (starteng(DL_SELECT_ENG_3,DL_TOGGLE_ENGINE3) == TRUE)
	{
		return TRUE;
	} else
	{
		return FALSE;
	}
}
/*! \brief Start Engine four. Actually, it selects the engine, toggles it, then selects all.

*/
bool C_DeviceLink::StartEng4()
{
	if (starteng(DL_SELECT_ENG_4,DL_TOGGLE_ENGINE4) == TRUE)
	{
		return TRUE;
	} else
	{
		return FALSE;
	}
}
/*! \brief Select/unselect Engine 1

*/
bool C_DeviceLink::ToggleEng1Select()
{	
	{
	MC_Lock m_Lock(&my_critsec);
	m_code_len = strlen(DL_TOGGLE_ENG1_SELECT);
	} //scope ender to force thread lock to deconstruct
	if (toggleswitch(DL_TOGGLE_ENG1_SELECT) == TRUE)
	{
		return TRUE;
	}
	return FALSE;
}

/*! \brief Select/unselect Engine 2

*/
bool C_DeviceLink::ToggleEng2Select()
{	
	{
	MC_Lock m_Lock(&my_critsec);
	m_code_len = strlen(DL_TOGGLE_ENG2_SELECT);
	} //scope ender to force thread lock to deconstruct
	if (toggleswitch(DL_TOGGLE_ENG2_SELECT) == TRUE)
	{
		return TRUE;
	}
	return FALSE;
}

/*! \brief Feather the selected engine

You must call the appropriate select engine prior to calling this. Otherwise
it defaults to Engine 1.

*/
bool C_DeviceLink::FeatherEngine()
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return FALSE;
	}
	{
	MC_Lock m_Lock(&my_critsec);
	m_code_len = strlen(DL_GET_FEATHER);
	} //scope ender to force thread lock to deconstruct
	int val = queryint(DL_GET_FEATHER);

	if (val == 1)
	{
		{
		MC_Lock m_Lock(&my_critsec);
		m_code_len = strlen(DL_TOGGLE_FEATHER);
		} //scope ender to force thread lock to deconstruct
		if (toggleswitch(DL_TOGGLE_FEATHER) == TRUE)
		{
			return TRUE;
		} else
		{
			return FALSE;
		} 
	} else
	{
		return FALSE;
	}
}


/*! \brief Simply executes command to select engine 1. returns bool.

*/
bool C_DeviceLink::SelectEng1()
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return FALSE;
	}
	{
	MC_Lock m_Lock(&my_critsec);
	m_code_len = strlen(DL_SELECT_ENG_1);
	}
	set_command_buff(DL_SELECT_ENG_1);
	if (SendMsg() == TRUE)
	{
		return TRUE;
	} else
	{
		return FALSE;
	}
}

/*! \brief Simply executes command to select engine 2. returns bool.
*/
bool C_DeviceLink::SelectEng2()
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return FALSE;
	}
	{
	MC_Lock m_Lock(&my_critsec);
	m_code_len = strlen(DL_SELECT_ENG_2);
	}
	set_command_buff(DL_SELECT_ENG_2);
	if (SendMsg() == TRUE)
	{
		return TRUE;
	} else
	{
		return FALSE;
	}
}

/*! \brief This function will populate the private engine data structure of the passed engine number. 

This function will fail if any part of it fails. This should be considered the "inefficient" 
method for filling in engine data.  I will do a single command string buffer for all 
engine data and rewrite this routine to be more efficient.

*/
bool C_DeviceLink::Set_Engine_Data(const int eng_num)
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return FALSE;
	}
	if ((eng_num < ENGINE_ONE) | (eng_num > ENGINE_FOUR))
	{
		errmsg("Set_Engine_Data called with invalid engine number.\n");
		return FALSE;
	}
	/********************************************************
	* Since a majority of the aircraft only have engine one *
	* we are going to make a special call to devicelink to  *
	* take advantage of the multiple query on a line aspect *
	* of the first engine data.                             *
	********************************************************/
	if (eng_num == ENGINE_ONE)
	{
		if ((set_engine_one_data() == FALSE))
		{
			errmsg("set_engine_one_data returned false.\n");
			return FALSE;
		} else 
		{
			return TRUE;
		}
	}
	if (Set_RPM(eng_num) == FALSE)
	{
		errmsg("Set_RPM returned FALSE.\n");
		return FALSE;
	}
	if (Set_Temp_Cyl(eng_num) == FALSE)
	{
		errmsg("Set_Temp_Cyl returned FALSE.\n");
		return FALSE;
	}
	if (Set_Temp_Oilin(eng_num) == FALSE)
	{
		errmsg("Set_Temp_Oilin returned FALSE.\n");
		return FALSE;
	}
	if (Set_Temp_Oilout(eng_num) == FALSE)
	{
		errmsg("Set_Temp_Oilout returned FALSE.\n");
		return FALSE;
	}
	if (Set_Temp_Water(eng_num) == FALSE)
	{
		errmsg("Set_Temp_Water returned FALSE.\n");
		return FALSE;
	}
	if (Set_Manifold(eng_num) == FALSE)
	{
		errmsg("Set_Manifold returned FALSE.\n");
		return FALSE;
	}

	return TRUE;
}

/*! \brief Sets the stored rpm value from the indexed engine

*/
bool C_DeviceLink::Set_RPM(const int eng_num)
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return FALSE;
	}
	if ((eng_num < ENGINE_ONE) | (eng_num > ENGINE_FOUR))
	{
		errmsg("Set_RPM called with invalid engine number.\n");
		return FALSE;
	}
	char temp_cmd[64];
	memset(temp_cmd,NULL,sizeof(temp_cmd));
#if _MSC_VER >= 1400
	_snprintf_s(temp_cmd,sizeof(temp_cmd),_TRUNCATE,"%c%c%s%c%c%d",REQUEST,DELIM_1,DL_GET_RPM,DELIM_1,DELIM_2,eng_num);
#else
	_snprintf(temp_cmd,sizeof(temp_cmd),"%c%c%s%c%c%d",REQUEST,DELIM_1,DL_GET_RPM,DELIM_1,DELIM_2,eng_num);
#endif
	
	int idx = 0;
	idx = eng_num - 1;
	{
	MC_Lock m_Lock(&my_critsec);
	m_engine[idx].rpm = queryfloat(temp_cmd);
	m_code_len = strlen(temp_cmd);
	}
	if (m_engine[idx].rpm < 0)
	{
		errmsg("failed to get rpm value from game. Setting to zero.\n");
		m_engine[idx].rpm = 0;
	}
	return TRUE;
}
/*! \brief Returns the stored Cylinder temperature (Celcius) in float from indexed engine

*/
float C_DeviceLink::Get_RPM(const int eng_num)
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return -1;
	}
	if ((eng_num < ENGINE_ONE) | (eng_num > ENGINE_FOUR))
	{
		errmsg("Get_RPM called with invalid engine number.\n");
		return -1;
	}
	int idx = 0;
	idx = eng_num - 1;
	MC_Lock m_Lock(&my_critsec);
	return m_engine[idx].rpm;
}
/*! \brief Sets the internal structure of the cylinder temp

*/
bool C_DeviceLink::Set_Temp_Cyl(const int eng_num)
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return FALSE;
	}
	if ((eng_num < ENGINE_ONE) | (eng_num > ENGINE_FOUR))
	{
		errmsg("Set_Temp_Cyl called with invalid engine number.\n");
		return FALSE;
	}
	char temp_cmd[32];
	memset(temp_cmd,NULL,sizeof(temp_cmd));
#if _MSC_VER >= 1400
	_snprintf_s(temp_cmd,sizeof(temp_cmd),_TRUNCATE,"%c%c%s%c%c%d",REQUEST,DELIM_1,DL_GET_TEMP_CYL,DELIM_1,DELIM_2,eng_num);
#else
	_snprintf(temp_cmd,sizeof(temp_cmd),"%c%c%s%c%c%d",REQUEST,DELIM_1,DL_GET_TEMP_CYL,DELIM_1,DELIM_2,eng_num);
#endif

	int idx = 0;
	idx = eng_num - 1;
	{
	MC_Lock m_Lock(&my_critsec);
	m_code_len = strlen(temp_cmd);
	m_engine[idx].temp_cylinders = queryfloat(temp_cmd);
	}
	if (m_engine[idx].temp_cylinders < 0.00)
	{
		errmsg("failed to get cylinder temperature value from game. Setting to zero.\n");
		m_engine[idx].temp_cylinders = 0.00;
	}
	return TRUE;
}

/*! \brief Returns the stored Cylinder temperature (Celsius) in float from indexed engine

*/
float C_DeviceLink::Get_Temp_Cyl(const int eng_num)
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return -1.00;
	}
	if ((eng_num < ENGINE_ONE) | (eng_num > ENGINE_FOUR))
	{
		errmsg("Get_Temp_Cyl called with invalid engine number.\n");
		return -1.00;
	}
	int idx = 0;
	idx = eng_num - 1;
	MC_Lock m_Lock(&my_critsec);
	return m_engine[idx].temp_cylinders;
}

/*! \brief Sets the Oil In temp in (Celsius) from the indexed engine.

*/
bool C_DeviceLink::Set_Temp_Oilin(const int eng_num)
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return FALSE;
	}
	if ((eng_num < ENGINE_ONE) | (eng_num > ENGINE_FOUR))
	{
		errmsg("Set_Temp_Oilin called with invalid engine number.\n");
		return FALSE;
	}
	char temp_cmd[32];
	memset(temp_cmd,NULL,sizeof(temp_cmd));
#if _MSC_VER >= 1400
	_snprintf_s(temp_cmd,sizeof(temp_cmd),_TRUNCATE,"R/%s/\\%d",DL_GET_TEMP_OILIN,eng_num);
#else
	_snprintf(temp_cmd,sizeof(temp_cmd),"%c%c%s%c%c%d",REQUEST,DELIM_1,DL_GET_TEMP_OILIN,DELIM_1,DELIM_2,eng_num);
#endif

	int idx = 0;
	idx = eng_num - 1;
	{
	MC_Lock m_Lock(&my_critsec);
	m_engine[idx].temp_oilin = queryfloat(temp_cmd);
	m_code_len = strlen(temp_cmd);
	}
	if (m_engine[idx].temp_oilin < 0.00)
	{
		errmsg("failed to get oilin temperature value from game. Setting to zero.\n");
		m_engine[idx].temp_oilin = 0.00;
	}
	return TRUE;
}

/*! \brief Returns the stored Cylinder temperature (Celsius) in float from indexed engine

*/
float C_DeviceLink::Get_Temp_Oilin(const int eng_num)
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return -1.00;
	}
	if ((eng_num < ENGINE_ONE) | (eng_num > ENGINE_FOUR))
	{
		errmsg("Get_Temp_Oilin called with invalid engine number.\n");
		return -1.00;
	}
	int idx = 0;
	idx = eng_num - 1;
	MC_Lock m_Lock(&my_critsec);
	return m_engine[idx].temp_oilin;
}

/*! \brief Sets the stored Oil Out temp (Celsius) from the indexed engine.

*/
bool C_DeviceLink::Set_Temp_Oilout(const int eng_num)
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return FALSE;
	}
	if ((eng_num < ENGINE_ONE) | (eng_num > ENGINE_FOUR))
	{
		errmsg("Set_Temp_Oilout called with invalid engine number.\n");
		return FALSE;
	}
	char temp_cmd[32];
	memset(temp_cmd,NULL,sizeof(temp_cmd));
#if _MSC_VER >= 1400
	_snprintf_s(temp_cmd,sizeof(temp_cmd),_TRUNCATE,"R/%s/\\%d",DL_GET_TEMP_OILOUT,eng_num);
#else
	_snprintf(temp_cmd,sizeof(temp_cmd),"%c%c%s%c%c%d",REQUEST,DELIM_1,DL_GET_TEMP_OILOUT,DELIM_1,DELIM_2,eng_num);
#endif

	int idx = 0;
	idx = eng_num - 1;
	{
	MC_Lock m_Lock(&my_critsec);
	m_code_len = strlen(temp_cmd);
	m_engine[idx].temp_oilout = queryfloat(temp_cmd);
	}
	if (m_engine[idx].temp_oilout < 0.00)
	{
		errmsg("failed to get oilout temperature value from game. Setting to zero.\n");
		m_engine[idx].temp_oilout = 0.00;
	}
	return TRUE;
}

/*! \brief Returns the stored Oil Out temperature (Celsius) in float from indexed engine

Fails on IsInitialized() failure or if invalid eng_num is passed in.

*/
float C_DeviceLink::Get_Temp_Oilout(const int eng_num)
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return -1.00;
	}
	if ((eng_num < ENGINE_ONE) | (eng_num > ENGINE_FOUR))
	{
		errmsg("Get_Temp_Oilout called with invalid engine number.\n");
		return -1.00;
	}
	int idx = 0;
	idx = eng_num - 1;
	MC_Lock m_Lock(&my_critsec);
	return m_engine[idx].temp_oilout;
}
/*! \brief Sets water temp in (Celsius) from the indexed engine.

*/
bool C_DeviceLink::Set_Temp_Water(const int eng_num)
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return FALSE;
	}
	if ((eng_num < ENGINE_ONE) | (eng_num > ENGINE_FOUR))
	{
		errmsg("Set_Temp_Water called with invalid engine number.\n");
		return FALSE;
	}
	int idx = 0;
	idx = eng_num - 1;
	{
	MC_Lock m_Lock(&my_critsec);
	m_engine[idx].temp_water = queryfloat(DL_GET_TEMP_WATER);
	m_code_len = strlen(DL_GET_TEMP_WATER);
	}
	if (m_engine[idx].temp_water < 0.00)
	{
		errmsg("failed to get water temperature value from game. Setting to zero.\n");
		m_engine[idx].temp_water = 0.00;
	}
	return TRUE;
}

/*! \brief Returns the stored Water temperature (Celsius) in float from indexed engine

*/
float C_DeviceLink::Get_Temp_Water(const int eng_num)
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return -1.00;
	}
	if ((eng_num < ENGINE_ONE) | (eng_num > ENGINE_FOUR))
	{
		errmsg("Get_Temp_Water called with invalid engine number.\n");
		return -1.00;
	}
	int idx = 0;
	idx = eng_num - 1;
	MC_Lock m_Lock(&my_critsec);
	return m_engine[idx].temp_water;
}

/*! \brief Sets the stored manifold pressure from the indexed engine by querying the game.

*/
bool C_DeviceLink::Set_Manifold(const int eng_num)
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return FALSE;
	}
	if ((eng_num < ENGINE_ONE) | (eng_num > ENGINE_FOUR))
	{
		errmsg("Set_Manifold called with invalid engine number.\n");
		return FALSE;
	}
	int idx = 0;
	idx = eng_num - 1;
	{
	MC_Lock m_Lock(&my_critsec);
	m_engine[idx].manifold = queryfloat(DL_GET_MANIFOLD);
	m_code_len = strlen(DL_GET_MANIFOLD);
	}
	if (m_engine[idx].manifold < 0.00)
	{
		errmsg("failed to get manifold pressure value from game. Setting to zero.\n");
		m_engine[idx].manifold = 0.00;
	}
	return TRUE;
}

/*! \brief Returns the stored manifold pressure in float from indexed engine

This value was set in Set_Manifold(const int eng_num).

*/
float C_DeviceLink::Get_Manifold(const int eng_num)
{
	if (IsInitialized() == FALSE)
	{
		init_err();
		return -1.00;
	}
	if ((eng_num < ENGINE_ONE) | (eng_num > ENGINE_FOUR))
	{
		errmsg("Get_Manifold called with invalid engine number.\n");
		return -1.00;
	}
	int idx = 0;
	idx = eng_num - 1;
	MC_Lock m_Lock(&my_critsec);
	return m_engine[idx].manifold;
}
/*! \brief Display init error

*/
void C_DeviceLink::init_err(void)
{
		errmsg("DeviceLink object not Initialized.\nYou must call Init() first!");
}

/*! \brief Output debug message if the debug has been turned on

*/
void C_DeviceLink::errmsg(const char* str)
{
#ifdef DEBUG_OUTPUT
	fprintf(dl_output, str);
#endif
}
/*! \brief This private function takes advantage of the fact that devicelink
will allow engine one data to be queried in a single string.

*/
bool C_DeviceLink::set_engine_one_data(void)
{
	//build the query string
	char temp_cmd[64];
	memset(temp_cmd, NULL,sizeof(temp_cmd));
{

#if _MSC_VER >= 1400
	_snprintf_s(temp_cmd,sizeof(temp_cmd),_TRUNCATE,"%s\0",ENG_1_REQ);
#else
	_snprintf(temp_cmd,sizeof(temp_cmd),"%s\0",ENG_1_REQ);
#endif
	m_code_len = strlen(temp_cmd);
}
	
	if ( QueryMsg(temp_cmd) == FALSE )
	{
		errmsg("QueryMsg returned false in set_engine_one_data.\n");
		return FALSE;
	}

	MC_Lock m_Lock(&my_critsec);
	m_engine[ENGINE_ONE].manifold = getfloatval(DL_GET_MANIFOLD);
	m_engine[ENGINE_ONE].temp_water = getfloatval(DL_GET_TEMP_WATER);
	m_engine[ENGINE_ONE].temp_oilout = getfloatval(DL_GET_TEMP_OILOUT);
	m_engine[ENGINE_ONE].temp_oilin = getfloatval(DL_GET_TEMP_OILIN);
	m_engine[ENGINE_ONE].temp_cylinders = getfloatval(DL_GET_TEMP_CYL);
	m_engine[ENGINE_ONE].rpm = getfloatval(DL_GET_RPM);
	return TRUE;
}
/*! \brief This will copy m_buff into the temp_buff to promote thread safety.

*/

bool C_DeviceLink::get_read_buff(char* temp_buff, unsigned int buff_size)
{
	if (temp_buff[0] != NULL)
	{
		errmsg("temp_buff not initialized to NULL in get_read_buff.\n");
		return FALSE;
	}
	if (buff_size < strlen(m_buff))
	{
		errmsg("Insufficient temp buffer size in get_read_buff.\n");
		return FALSE;
	}
	MC_Lock m_Lock(&my_critsec);
	dl_strncpy(temp_buff, m_buff,buff_size);	
	return TRUE;
}

/*! \brief This copies the string temp_buff into m_buff.

*/
bool C_DeviceLink::set_read_buff(const char* temp_buff, unsigned int buff_size)
{
	if (temp_buff == NULL)
	{
		MC_Lock m_Lock(&my_critsec);
		memset(m_buff, NULL,sizeof(m_buff));
		return TRUE;
	}
	if (buff_size > sizeof(m_buff))
	{
		errmsg("temp buffer size too large for m_buff in set_read_buff.\n");
		return FALSE;
	}
	MC_Lock m_Lock(&my_critsec); 
	dl_strncpy(m_buff,const_cast<char *>(temp_buff), sizeof(m_buff));	
	return TRUE;
}

/*! \brief Thread-safe method of setting the m_readdata flag. 

m_readdata is used to verify that data has, in fact, been read from 
the game before trying to process it.

*/
bool C_DeviceLink::set_has_read_data(bool flag)
{
	MC_Lock m_Lock(&my_critsec);
	m_readdata = flag;
	return TRUE;
}

/*! \brief Returns the contents of m_cmd buffer and places it into temp_buff.

*/
bool C_DeviceLink::get_cmd_buff(char* temp_buff, unsigned int buff_size)
{
	if (temp_buff[0] != NULL)
	{
		errmsg("temp_buff not initialized to NULL in get_cmd_buff.\n");
		return FALSE;
	}
	if (buff_size < strlen(m_cmd))
	{
		errmsg("Insufficient temp buffer size in get_cmd_buff.\n");
		return FALSE;
	}
	MC_Lock m_Lock(&my_critsec); 
	dl_strncpy(temp_buff, m_cmd, buff_size);
	return TRUE;
}
/*! \brief modified copy command to distinguish between VS2003 and VS2005 buffer handling.

*/
void C_DeviceLink::dl_strncpy(char * dest_str, char * src_str, unsigned int dest_size)
{
#if _MSC_VER >= 1400
	strncpy_s(dest_str, dest_size, src_str,_TRUNCATE);
#else
	strncpy(dest_str, src_str,dest_size);	
#endif
}

