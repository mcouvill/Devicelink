#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdlib.h>
#include <stdio.h>

#define DEFAULT_PORT "10000"
#define DEFAULT_BUFLEN 80
#define DEFAULT_IP "127.0.0.1"

