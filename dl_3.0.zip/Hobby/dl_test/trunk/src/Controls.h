/*! \file C_Controls.h
\brief Main header file for the C_Controls class
\author Mike Couvillion
\date Copyright 2004-2007

\note This code is free to use for free utilities. It is not free for commercial use.  
Not responsible for any errors. Use at your own risk. If you do use the code I ask you
give proper credit.
*/
#pragma once
#include "devicelink.h"

class C_Controls
{
	public:
		C_Controls(void);
		C_Controls(C_DeviceLink* dl);
		~C_Controls(void);
		bool SetFlaps(float flap_pos);
		float GetFlaps(void);
		bool SetAileron(float ail_pos);
		float GetAileron(void);
		bool SetElevator(float ail_pos);
		float GetElevator(void);
		bool SetRudder(float ail_pos);
		float GetRudder(void);
		bool SetAileronTrim(float ail_pos);
		float GetAileronTrim(void);
		bool SetElevatorTrim(float ail_pos);
		float GetElevatorTrim(void);
		bool SetRudderTrim(float ail_pos);
		float GetRudderTrim(void);
		bool SetPower(const int eng_idx, float pos);
		float GetPower(const int eng_idx);
		bool DeployAirbrake(void);
		bool RetractAirbrake(void);
		bool CowlFlaps(void);
		bool LvlStabOn(void);
		bool LvlStabOff(void);

	private:
		C_DeviceLink* m_dl;
		int getairbrake(void);
		int getlvlstab(void);	
		bool toggleairbrake(int i);
		bool togglelvlstab(int i);
};
