/*! \file Weapon.h
	\brief The main header file for the Weapon class
	\author Mike Couvillion
	\date 2004-2007 Copyright.
*/
#pragma once
#include "devicelink.h"

class C_Weapon
	{
	public:
		C_Weapon(void);
		C_Weapon(C_DeviceLink* dl, WeapType weap);
		~C_Weapon(void);
		bool Fire(void);
		bool CeaseFire(void);
		int GetWeaponState(void);
		bool IncBombSightAngle(void);
		bool DecBombSightAngle(void);
		bool IncBombSightAlt(void);
		bool DecBombSightAlt(void);
		bool IncBombSightSpeed(void);
		bool DecBombSightSpeed(void);
		bool AdjSightRight(void);
		bool AdjSightLeft(void);
		bool ToggleGunPods(void);
		int GetGunPods(void);
    private:
		C_DeviceLink* m_dl; 
		WeapType m_weap_idx; //!< identifies which weapon this is. 1 is Weapon 1 etc...
	};
