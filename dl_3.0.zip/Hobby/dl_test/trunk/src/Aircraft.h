/*! \file Aircraft.h
\brief Main header file for the C_Aircraft Class
\author Mike Couvillion
\date Copyright 2004-2007

\note Why didn't I make the C_DeviceLink object public and just call that routine?
Because one goal I had in this example app was to abtract away the entire DeviceLink
class altogether. I wanted the end programmer to be able to code an app knowing NOTHING
about DeviceLink.

\note This code is free to use for free utilities. It is not free for commercial use.  
Not responsible for any errors. Use at your own risk. If you do use the code I ask you
give proper credit.
*/
#pragma once
#include <stdio.h>
#include <iostream>
#include "devicelink.h"
#include "LandingGear.h"
#include "Engine.h"
#include "Instruments.h"
#include "Controls.h"
#include "Lights.h"
#include "Weapon.h"
#include "Cockpits.h"
#define MAX_PITS 10
/*! \brief The primary Aircraft class.

This is the main class for a test application. I don't pretend this is the BEST example
of how to use the devicelink library but it is one design that is simple to use. For example,
I chose to make the DeviceLink object a private variable inside of the Aircraft class and
pass that variable to the other various classes.  I could have instantiated it separately
and made the other classes friends of Aircraft and save some heap stack for example.

I also chose NOT to make the other classes sub-classes of Aircraft though there isn't a 
reason to do so.  This was more of a personal preference.

Likewise, it is entirely possbile to use the DeviceLink class directly and not have these 
additional classes at all. I chose this particular method to abstract the DeviceLink layer
completely away so an end developer could write the code without having to know anything
about DeviceLink beyond an IP address and a port in the config file.
*/
class C_Aircraft
{
public:
	C_Aircraft(void);
	~C_Aircraft(void);	
	bool InitDeviceLink(void); //!< initializes the communications  link with the game.
	C_LandingGear* Gear(void);
	C_Engine* Engine(const int eng_idx);
	C_Controls* Controls(void);
	C_Instruments* Instruments(void);
	C_Lights* Lights(void);
	C_Weapon* Weapon(const int weap_num);
	C_Cockpits* Cockpits(const int pit_idx);
	bool IsGetValid(const char* code);
	int GetNumEngines(void);
	int GetNumCockpits(void);
	char* GetDLVersion(void);
	char* GetAircraftName(void);
	void CreateEngine(const int eng_idx);
	void CreateCockpit(int pit_idx);


private:
	C_DeviceLink m_dl; //!< devicelink object
	C_LandingGear *m_gear; //!< stores an aircraft landing gear data
	C_Engine *m_eng1; //!< pointer to engine 1 object
	C_Engine *m_eng2; //!< pointer to engine 2 object
	C_Engine *m_eng3; //!< pointer to engine 3 object
	C_Engine *m_eng4; //!< pointer to engine 4 object
	C_Weapon *m_weap1; //!< weapon number one
	C_Weapon *m_weap2; //!< weapon number two
	C_Weapon *m_weap3; //!< weapon number three
	C_Weapon *m_weap4; //!< weapon number four
	C_Weapon *m_weap5; //!< weapon number five which is a combo for 1 and 2
	C_Instruments *m_inst; //!< pointer to instruments object
	C_Controls *m_ctrl; //!< pointer to controls object
	C_Lights *m_lights; //!< pointer to lights object
	C_Cockpits *m_pit[MAX_PITS]; //!< point to cockpit object


	char m_dl_ver[64]; //!< holds the string of the current DeviceLink version
	char m_ac_name[64]; //!< holds the name of the current aircraft object
};
