/*! \file LandingGear.h
	\brief The main header file for the C_LandingGear class
	\author Mike Couvillion
	\date 2004-2007 Copyright.
*/
#pragma once
#include "devicelink.h"

class C_LandingGear
	{
	public:
		C_LandingGear(void);
		C_LandingGear(C_DeviceLink* dl);
		~C_LandingGear(void);
		bool Raise(void);
		bool Lower(void);
		bool QueryPos(void);
		float GetLeftPos(void);
		float GetRightPos(void);
		float GetCenterPos(void);
		bool LockTailWheel(void);
		bool ManualRaise(void);
		bool ManualLower(void);
		bool ChocksIn(void);
		bool ChocksOut(void);
	private:
		C_DeviceLink* m_dl;
		float m_right_pos;
		float m_center_pos;
		float m_left_pos;
		int getchocks(void);
		bool togglechocks(int i);
	};
