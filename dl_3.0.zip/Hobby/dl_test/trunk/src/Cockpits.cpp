/*! \file Cockpits.cpp
\brief Main source file for the C_Cockpits class
\author Mike Couvillion
\date Copyright 2004-2007

\note This code is free to use for free utilities. It is not free for commercial use.  
Not responsible for any errors. Use at your own risk. If you do use the code I ask you
give proper credit.
*/
#include "Cockpits.h"

C_Cockpits::C_Cockpits(void)
: m_dl(NULL)
{
}
C_Cockpits::C_Cockpits(C_DeviceLink* dl, const int pit_idx)
: m_dl(dl)
, m_pitnum(pit_idx)
{
}
C_Cockpits::~C_Cockpits(void)
	{
	}
/*! \brief gets the current state of the canopy
\return \b integer : returns a 1 if in use and 0 if not

*/
int C_Cockpits::getcanopy(void)
{
	if (true == m_dl->Query_Canopy())
	{
		return m_dl->Get_Canopy();
	}
	return 0;
}

/*! \brief toggles the state of the canopy
\return \b boolean
*/
bool C_Cockpits::togglecanopy(int i)
{
	if (i == getcanopy())
	{
		return m_dl->Set_Canopy();
	}
	return true;
}
/*! \brief opens the canopy
\return \b boolean
*/
bool C_Cockpits::OpenCanopy(void)
{
	return togglecanopy(1);
}
/*! \brief closes the canopy
\return boolean
*/
bool C_Cockpits::CloseCanopy(void)
{
	return togglecanopy(0);
}
