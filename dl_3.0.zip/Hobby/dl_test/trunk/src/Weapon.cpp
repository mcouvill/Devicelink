/*! \file Weapon.cpp
	\brief The main source file for the Weapon class
	\author Mike Couvillion
	\date 2004-2007 Copyright.
*/

#include "Weapon.h"
C_Weapon::C_Weapon(void)
: m_dl(NULL)
, m_weap_idx(MG)
{
}
C_Weapon::C_Weapon(C_DeviceLink* dl, WeapType weap)
: m_dl(dl)
, m_weap_idx(weap)
{
}
C_Weapon::~C_Weapon(void)
{
}

/*!  \brief Fires the weapon
\return \b boolean

*/
bool C_Weapon::Fire(void)
{
	return m_dl->Set_Weapon(m_weap_idx, 1);
}

/*!  \brief Ceases firing the weapon
\return \b boolean

*/
bool C_Weapon::CeaseFire(void)
{
	return m_dl->Set_Weapon(m_weap_idx, 0);
}

/*!  \brief checks the status of the weapon
\return \b boolean

*/
int C_Weapon::GetWeaponState(void)
{
	if (true == m_dl->Query_Weapon(m_weap_idx))
	{
		return m_dl->Get_Weapon(m_weap_idx);
	}
	return -1;
}

/*!  \brief increases the bombsight angle
\return \b boolean

*/
bool C_Weapon::IncBombSightAngle(void)
{
	return m_dl->IncSightDist();
}

/*!  \brief decreases the bombsight angle
\return \b boolean

*/
bool C_Weapon::DecBombSightAngle(void)
{
	return m_dl->DecSightDist();
}

/*!  \brief adjusts the bombsight left
\return \b boolean

*/
bool C_Weapon::AdjSightLeft(void)
{
	return m_dl->AdjSightLeft();
}

/*!  \brief adjusts the bombsight right 
\return \b boolean

*/
bool C_Weapon::AdjSightRight(void)
{
	return m_dl->AdjSightRight();
}

/*!  \brief increases the bombsight altitude 
\return \b boolean

*/
bool C_Weapon::IncBombSightAlt(void)
{
	return m_dl->IncSightAlt();
}

/*!  \brief increases the bombsight altitude 
\return \b boolean

*/
bool C_Weapon::DecBombSightAlt(void)
{
	return m_dl->DecSightAlt();
}

/*!  \brief increases the bombsight speed 
\return \b boolean

*/
bool C_Weapon::IncBombSightSpeed(void)
{
	return m_dl->IncSightVelocity();
}

/*!  \brief increases the bombsight speed 
\return \b boolean

*/
bool C_Weapon::DecBombSightSpeed(void)
{
	return m_dl->DecSightVelocity();
}

/*!  \brief toggle the gunpods on/off
\return \b boolean

*/
bool C_Weapon::ToggleGunPods(void)
{
	return m_dl->ToggleGunPods();
}

/*!  \brief queries the game for gunpod state
\return \b int : 0 is off, 1 is on

*/
int C_Weapon::GetGunPods(void)
{
	if (true == m_dl->Query_GunPods())
	{
		return m_dl->GetGunPodsState();
	}
	return 0;
}