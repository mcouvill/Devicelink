/*! \file LandingGear.cpp
	\brief The main source file for the Aircraft class
	\author Mike Couvillion
	\date 2004-2007 Copyright.
*/
#include "LandingGear.h"
/*! \brief Constructor. Mainly initializes the private member variables.

*/
C_LandingGear::C_LandingGear(void)
: m_left_pos(0)
, m_right_pos(0)
, m_center_pos(0)
	{
	}
/*! \brief Constructor. Mainly initializes the private member variables.
\param C_DeviceLink::m_dl : the devicelink communications object

*/
C_LandingGear::C_LandingGear(C_DeviceLink* dl)
: m_left_pos(0)
, m_right_pos(0)
, m_center_pos(0)
, m_dl(dl)
{
}
/*! \brief LandingGear class destructor

 */
C_LandingGear::~C_LandingGear(void)
{
}
/*! \brief Raises the landing gear
\return \b boolean 
*/
bool C_LandingGear::Raise(void)
	{
	return m_dl->SetGearUp();
	}
/*! \brief Lowers the landing gear
\return \b boolean 
*/
bool C_LandingGear::Lower(void)
	{
	return m_dl->SetGearDown();
	}
/*! \brief queries the game via the m_dl object for gear positions
\return \b boolean 
*/
bool C_LandingGear::QueryPos(void)
{
	m_left_pos = m_dl->GetGearPos(DL_GET_LEFT_GEAR_POS);
	m_right_pos = m_dl->GetGearPos(DL_GET_RIGHT_GEAR_POS);
	m_center_pos = m_dl->GetGearPos(DL_GET_CENTER_GEAR_POS);
	if ((0 <= m_left_pos) && (0 <= m_right_pos) && (0 <= m_center_pos))
		{
			return true;
		} else
		{
			return false;
		}
}
/*! \brief returns the position of the left landing gear
\return \b float
*/
float C_LandingGear::GetLeftPos(void)
{
	return m_left_pos;
}
/*! \brief returns the position of the right landing gear
\return \b float
*/
float C_LandingGear::GetRightPos(void)
{
	return m_right_pos;
}
/*! \brief returns the position of the center landing gear
\return \b float
*/
float C_LandingGear::GetCenterPos(void)
{
	return m_center_pos;
}

/*! \brief send manual lower command
\return \b boolean
*/
bool C_LandingGear::ManualLower(void)
{
	return m_dl->ManualGearDown();
}

/*! \brief send manual raise command
\return \b boolean
*/
bool C_LandingGear::ManualRaise(void)
{
	return m_dl->ManualGearUp();
}

/*! \brief gets the current state of the chocks
\return \b integer : returns a 1 if in use and 0 if not

*/
int C_LandingGear::getchocks(void)
{
	if (true == m_dl->Query_Chocks())
	{
		return m_dl->Get_Chocks();
	}
	return 0;
}

/*! \brief toggles the state of the chocks
\return \b boolean
*/
bool C_LandingGear::togglechocks(int i)
{
	if (i == getchocks())
	{
		return m_dl->Set_Chocks();
	}
	return true;
}
/*! \brief puts in the chocks in place
\return \b boolean
*/
bool C_LandingGear::ChocksIn(void)
{
	return togglechocks(1);
}
/*! \brief removes the chocks
\return boolean
*/
bool C_LandingGear::ChocksOut(void)
{
	return togglechocks(0);
}