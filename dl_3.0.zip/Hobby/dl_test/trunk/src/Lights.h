/*! \file Lights.h
\brief Main header file for the C_Lights Class
\author Mike Couvillion
\date Copyright 2004-2007

\note OK, so why didn't I create a base Light class and then subclass the various lights?
Well, mainly because the only thing you can do with the lights is toggle them. There isn't
even a command available for checking their current state so no use to bother with a lot of Class
overhead.  Ultimately, I do just end up using one toggleswitch routine in the DeviceLink class and
just pass in the proper command so it's not really a lot of wasted code.

\note This code is free to use for free utilities. It is not free for commercial use.  
Not responsible for any errors. Use at your own risk. If you do use the code I ask you
give proper credit.
*/

#pragma once
#include "devicelink.h"

class C_Lights
{
	public:
		C_Lights(void);
		C_Lights(C_DeviceLink* dl);
		~C_Lights(void);
		bool ToggleLanding(void);
		bool ToggleNav(void);
		bool TogglePanel(void);
	private:
		C_DeviceLink* m_dl;
};
