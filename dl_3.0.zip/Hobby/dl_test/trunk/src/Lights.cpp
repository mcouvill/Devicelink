#include "Lights.h"

/*! \brief primary constructor and requires devicelink object passed in

*/
C_Lights::C_Lights(C_DeviceLink* dl)
: m_dl(dl)
	{
	}

/*! \brief default constructor required by compiler. not used.

*/
C_Lights::C_Lights(void)
: m_dl(NULL)
	{
	}

C_Lights::~C_Lights(void)
	{
	}

/*! \brief toggle the panel lights
\return \b boolean

*/
bool C_Lights::TogglePanel(void)
	{
	return m_dl->ToggleCockpitLights();
	}
/*! \brief toggle the landing lights
\return \b boolean

*/
bool C_Lights::ToggleLanding(void)
	{
	return m_dl->ToggleLandLights();
	}

/*! \brief toggle the Nav lights
\return \b boolean

*/
bool C_Lights::ToggleNav(void)
	{
	return m_dl->ToggleNavLights();
	}
