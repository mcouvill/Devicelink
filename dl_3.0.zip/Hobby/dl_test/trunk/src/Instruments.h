/*! \file Instruments.h
	\brief The main header file for the C_Instruments class
	\author Mike Couvillion
	\date 2004-2007 Copyright.
*/
#pragma once
#include "devicelink.h"
#include <cmath>

class C_Instruments
	{
	public:
		C_Instruments(void);
		C_Instruments(C_DeviceLink* dl);
		~C_Instruments(void);
		bool SetIAS(void);
		float GetIAS(void);
		void SetVario(void);
		float GetVario(void);
		bool SetSlip(void);
		float GetSlip(void);
		bool SetTurn(void);
		float GetTurn(void);
		void SetAngSpd(void);
		float GetAngSpd(void);
		bool SetAlt(void);
		float GetAlt(void);
		bool SetAzimuth(void);
		float GetAzimuth(void);
		bool SetBeaconAzimuth(void);
		float GetBeaconAzimuth(void);
		bool SetRoll(void);
		float GetRoll(void);
		bool SetPitch(void);
		float GetPitch(void);
		bool SetFuel(void);
		float GetFuel(void);
		bool SetAll(void);
		float GetTAS(Speed type = KMH);
	private:
		C_DeviceLink* m_dl;

		
	};
