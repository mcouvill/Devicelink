/*! \file Engine.cpp
	\brief The main source file for the Engine class
	\author Mike Couvillion
	\date 2004-2007 Copyright.
*/
#include "Engine.h"

C_Engine::C_Engine(C_DeviceLink* dl, int engidx)
: m_dl(dl)
, m_eng_idx(engidx)
{
}

C_Engine::C_Engine(void)
: m_dl(NULL)
, m_eng_idx(0)
{
}
C_Engine::~C_Engine(void)
{
}

/*! \brief Queries the game for the engine RPM. Sets the private variable
\return \b boolean
*/
float C_Engine::GetRPM(void)
{
	return m_dl->Get_RPM(m_eng_idx);
}

/*! \brief Queries the game for the engine manifold. Sets the private variable
\return \b boolean
*/
float C_Engine::GetMani(void)
{
	return m_dl->Get_Manifold(m_eng_idx);
}

/*! \brief Queries the game for the engine oil in temp. Sets the private variable
\return \b boolean
*/
float C_Engine::GetOilin(void)
{
	return m_dl->Get_Temp_Oilin(m_eng_idx);
}

/*! \brief Queries the game for the engine oil out temp. Sets the private variable
\return \b boolean
*/
float C_Engine::GetOilout(void)
{
	return m_dl->Get_Temp_Oilout(m_eng_idx);
}

/*! \brief Queries the game for the engine cylinder temp. Sets the private variable
\return \b boolean
*/
float C_Engine::GetCyl(void)
{
	return m_dl->Get_Temp_Cyl(m_eng_idx);
}

/*! \brief Queries the game for the engine water temp. Sets the private variable
\return \b boolean
*/
float C_Engine::GetWater(void)
{
	return m_dl->Get_Temp_Water(m_eng_idx);
}

/*! \brief Queries the game for the number of magnetos for this engine. Sets the private variable
\return \b boolean
*/
int C_Engine::GetNumMags(void)
{
	return m_dl->GetMags(m_eng_idx);
}

/*! \brief queries the game for the appropriate engine data and set the variables in the
devicelink object

\return \b boolean

\note should call this first before calling the other Get functions
*/
bool C_Engine::SetData(void)
{
	return m_dl->Set_Engine_Data(m_eng_idx);
}
/*! \brief Calls the appropriate StartEng routine based on the index of this engine object.
\return \b boolean
*/
bool C_Engine::Start(void)
{
	switch (m_eng_idx)
	{
		case ENGINE_ONE:
			return m_dl->StartEng1();
			break;
		case ENGINE_TWO:
			return m_dl->StartEng2();
			break;
		case ENGINE_THREE:
			return m_dl->StartEng3();
			break;
		case ENGINE_FOUR:
			return m_dl->StartEng4();
			break;
		default:
			return m_dl->StartEng1();
	}
}

/*! \brief command to Stop the engine
\return \b boolean
\sa GetRPM
\sa Start()

\note taking advantage of the fact that the StartEngine function performs the
exact same function as toggling the engine. Assumes RPMs > 0 if engine is running.
*/
bool C_Engine::Stop(void)
{
	if (0.00 >= GetRPM())
	{
		return Start();
	}
	return false;
}
/*! \brief Queries the game for the current state of the WEP switch.
\return \b int : 1 means WEP on and 0 means WEP off
\sa Get_WEP()

*/
int C_Engine::wep_state()
{
	return m_dl->Get_WEP();
}
/*! \brief Turns WEP on.
\sa wep_sate()
\sa m_dl->ToggleWEP()

*/
void C_Engine::WEPOn()
{
	if (0 == wep_state())
	{
		m_dl->ToggleWEP();
	}
}
/*! \brief Turns WEP off.
\sa

*/
void C_Engine::WEPOff()
{
	if (1 == wep_state())
	{
		m_dl->ToggleWEP();
	}
}

/*! \brief Feathers the prop
\return void

*/
bool C_Engine::Feather()
{
	bool flag = false;
	switch (m_eng_idx)
	{
		case ENGINE_ONE:
			flag =  m_dl->SelectEng1();
			break;
		case ENGINE_TWO:
			flag = m_dl->SelectEng2();
			break;
		case ENGINE_THREE:
			flag = m_dl->SelectEng3();
			break;
		case ENGINE_FOUR:
			flag = m_dl->SelectEng4();
			break;
		default:
			flag =  m_dl->SelectEng1();
	}	
	if (true == flag)
	{
		return m_dl->FeatherEngine();
	} else
	{
		return false;
	}
}

/*! \brief increases the supercharger to the next stage.
\return void

*/
bool C_Engine::SuperChargerNext()
{
	return m_dl->SuperChgNxt(m_eng_idx);
}

/*! \brief increases the supercharger to the prev stage.
\return void

*/
bool C_Engine::SuperChargerPrev()
{
	return m_dl->SuperChgPrv(m_eng_idx);
}

/*! \brief Selects next magneto
\return \b boolean
\todo need to add next magneto function to devicelink class.

*/
bool C_Engine::MagNext()
{
	return true;
}

/*! \brief Selects prev magneto
\return \b boolean
\todo need to add prev magneto function to devicelink class.

*/
bool C_Engine::MagPrev()
{
	return true;
}

/*! \brief Turns on the Fire extinguisher
\return \b boolean
\todo need to add fire extinguisher to devicelink class

*/
bool C_Engine::FireExt()
{
	bool flag = false;
	switch (m_eng_idx)
	{
		case ENGINE_ONE:
			flag =  m_dl->SelectEng1();
			break;
		case ENGINE_TWO:
			flag = m_dl->SelectEng2();
			break;
		case ENGINE_THREE:
			flag = m_dl->SelectEng3();
			break;
		case ENGINE_FOUR:
			flag = m_dl->SelectEng4();
			break;
		default:
			flag =  m_dl->SelectEng1();
	}	
	if (true == flag)
	{
		return true;
		//return m_dl->FeatherEngine();
	} else
	{
		return false;
	}
}
