/*! \file dl_test.cpp
\brief Main example app file
\author Mike Couvillion
\version 2.0.0
\date Copyright 2004-2007
\note This file utilizes the Aircraft class I wrote with the sub-component classes underneath.
In this example I have abstracted the devicelink layer completely away so the end programmer 
doesn't need to know anything about devicelink or network coding for it to work just fine.
\note This code is free to use for free utilities. It is not free for commercial use.  
Not responsible for any errors. Use at your own risk. If you do use the code I ask you
give proper credit.
*/
#include <iostream>
#include <fstream>
#include <tchar.h>
#include "Aircraft.h"
using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	//parse command line options exit if there are any.
	//will change this in the future to allow IP, port and log file to be input
	//on command line
	int arg_cnt = argc;
	char fp[64];
	memset(fp,NULL,sizeof(fp));
	strcpy(fp,"logfile.cvs");
	if (arg_cnt > 2)
	{
		return 1;
	} else if (arg_cnt == 2)
	{
		strcpy(fp, argv[1]); //used command line filename as logfile name
	}
	ofstream log( fp , ios::out ); //opent he file for output
	if (!log)
	{
		cout << "Cannot open the log file: " << fp << "\n";
		return 1;
	}

	//Instantiate the aircraft object.
	C_Aircraft ac;
	char* acname = NULL;
	acname = ac.GetAircraftName();
	if (acname != NULL)
	{
		log << "Aircraft: " << acname << "\n";
	}
	log << "IAS, ALT, ANGSPD, AZIMUTH, "; //set the headers
	log << "ROLL, PITCH, TURN, SLIP, VARIO, FUEL";
	log << "KTS TAS, KMH TAS, MPH TAS\n";
	log.flush();	

	//create the needed number of engine objects.
	int eng_cnt = ac.GetNumEngines();
	switch (eng_cnt)
	{
		case 4:
			ac.CreateEngine(ENGINE_FOUR);
		case 3:
			ac.CreateEngine(ENGINE_THREE);
		case 2:
			ac.CreateEngine(ENGINE_TWO);
			break;
		case 1:
			break;
		default:
			break;
	}

	int pit_cnt = ac.GetNumCockpits();
	if (1 < pit_cnt)
	{
		for (int cnt = 1; cnt < pit_cnt; ++cnt)
		{
			ac.CreateCockpit(cnt);
		}
	}
	while (true == ac.IsGetValid(DL_GET_ALT))
	{
/*		ac.Instruments()->SetAll(); // uses single command to set all the instrument variables
		float spd = ac.Instruments()->GetIAS();
		float alt = ac.Instruments()->GetAlt();
		float angspd = ac.Instruments()->GetAngSpd();
		float azi = ac.Instruments()->GetAzimuth();
		float roll = ac.Instruments()->GetRoll();
		float pitch = ac.Instruments()->GetPitch();
		float fuel = ac.Instruments()->GetFuel();
		float turn = ac.Instruments()->GetTurn();
		float slip = ac.Instruments()->GetSlip();
		float vario = ac.Instruments()->GetVario();
		float tas = ac.Instruments()->GetTAS(KMH);
		float kts_tas = ac.Instruments()->GetTAS(KTS);
		float mph_tas = ac.Instruments()->GetTAS(MPH);*/

/*cout << "ias = " << spd << "\n";
cout << "tas km/h = " << tas << " ";
cout << "tas mph = " << mph_tas << " ";
cout << "kts_tas = " << kts_tas << "\n"; 

		log << spd << "," << alt << "," << angspd << "," << azi << ",";
		log << roll <<"," << pitch << "," << turn << "," << slip << ",";
		log << vario << "," << fuel << "," << kts_tas << "," << tas << "," << mph_tas << " \n"; */

		log.flush();
		Sleep(500);

	}
	log << "Error: Invalid return from game. Is the server up?\n";
	log.flush();	
	log.close();
	return 1;
}

