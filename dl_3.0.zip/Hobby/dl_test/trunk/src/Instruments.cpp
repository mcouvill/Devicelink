/*! \file Instruments.cpp
	\brief The main source file for the C_Instruments class
	\author Mike Couvillion
	\date 2004-2007 Copyright.
*/
#include "Instruments.h"


C_Instruments::C_Instruments(void)
: m_dl(NULL)
{
}
C_Instruments::C_Instruments(C_DeviceLink* dl)
: m_dl(dl)
{
}
C_Instruments::~C_Instruments(void)
{
}
/*! \brief query game and set private variable for IAS
\return \b boolean : returns whether the query to the game was successful.
*/
bool C_Instruments::SetIAS(void)
{
	return m_dl->Set_IAS();
}

/*! \brief  return True Airspeed based on "rule of thumb" formula
\param \b Speed : Enumerated type {KMH, KTS, MPH}
\return \b float : true airspeed

\note Rule Of Thumb formula used is TAS = IAS +((IAS*.02)*(Alt/1000ft)) with
all data being in imperial.  The formulas are then converted to the other formats.
The calling function simply passes either KMH, KTS or MPH to indicate the type of 
TAS you want returned.

*/
float C_Instruments::GetTAS(Speed type)
{
	double kts_tas = 0.00;
	float ias = GetIAS();
	float alt = GetAlt();
//	float feet_alt = static_cast<float>(alt * 3.28);
	float kts_ias = static_cast<float>(ias * 0.54);
	float T = 15.0 + 273.0;
	double base = 1.00 - (0.22558*alt);
	double fpow = 5.25611;
	double p = pow(base, fpow);
	double P = (1013.25*p);
	
	kts_tas = kts_ias*(sqrt(1013.25*T/(P*288.15)));
//	kts_tas = static_cast<float>(kts_ias + ((kts_ias *.02)*(floor((feet_alt/1000)))));
	switch (type)
	{
		case KTS:
			return static_cast<float>(kts_tas);
			break;
		case MPH:
			return static_cast<float>(kts_tas * 1.15);
			break;
		case KMH:
            return static_cast<float>(kts_tas * 1.85);
			break;
		default:
            return static_cast<float>(kts_tas * 1.85);
			break;
	}
}
/*! \brief returns indicated airspeed in km/hour
\return \b float : IAS in km/h

*/
float C_Instruments::GetIAS(void)
{
	return m_dl->Get_IAS();
}

/*! \brief query game and set private variable for variometer
\return \b boolean : returns whether the query to the game was successful.
*/
void C_Instruments::SetVario(void)
{
	m_dl->Set_Vario();
}
/*! \brief returns variometer in meters/seconds
\return \b float : IAS in m/s

*/
float C_Instruments::GetVario(void)
{
	return m_dl->Get_Vario();
}

/*! \brief query game and set private variable for slip
\return \b boolean : returns whether the query to the game was successful.
*/
bool C_Instruments::SetSlip(void)
{
	return m_dl->Set_Slip();
}
/*! \brief returns Slip in degrees
\return \b float : Slip in degrees

*/
float C_Instruments::GetSlip(void)
{
	return m_dl->Get_Slip();
}

/*! \brief query game and set private variable for turn
\return \b boolean : returns whether the query to the game was successful.
*/
bool C_Instruments::SetTurn(void)
{
	return m_dl->Set_Turn();
}
/*! \brief returns turn indicator ranging from -1.00 to 1.00
\return \b float : turn indicator -1.00 to 1.00

*/
float C_Instruments::GetTurn(void)
{
	return m_dl->Get_Turn();
}

/*! \brief query game and set private variable for AngSpd
\return \b boolean : returns whether the query to the game was successful.
*/
void C_Instruments::SetAngSpd(void)
{
	m_dl->Set_AngSpd();
}
/*! \brief returns angular speed ranging from -infinity to +infinity
\return \b float : angular speed in degrees/second

*/
float C_Instruments::GetAngSpd(void)
{
	return m_dl->Get_AngSpd();
}

/*! \brief query game and set private variable for Alt
\return \b boolean : returns whether the query to the game was successful.
*/
bool C_Instruments::SetAlt(void)
{
	return m_dl->Set_Alt();
}
/*! \brief returns the altitude in meters
\return \b float : altitude in meters

*/
float C_Instruments::GetAlt(void)
{
	return m_dl->Get_Alt();
}

/*! \brief query game and set private variable for azimuth(heading)
\return \b boolean : returns whether the query to the game was successful.
*/
bool C_Instruments::SetAzimuth(void)
{
	return m_dl->Set_Azimuth();
}
/*! \brief returns the azimuth in degrees
\return \b float : azimuth in degrees +0.00 thru +359.9

*/
float C_Instruments::GetAzimuth(void)
{
	return m_dl->Get_Azimuth();
}

/*! \brief query game and set private variable for Beacon Azimuth
\return \b boolean : returns whether the query to the game was successful.
*/
bool C_Instruments::SetBeaconAzimuth(void)
{
	return m_dl->Set_BeaconAzimuth();
}
/*! \brief returns the beacon azimuth in degrees
\return \b float : beacon azimuth in degrees +0.00 thru +359.9

*/
float C_Instruments::GetBeaconAzimuth(void)
{
	return m_dl->Get_BeaconAzimuth();
}

/*! \brief query game and set private variable for roll
\return \b boolean : returns whether the query to the game was successful.
*/
bool C_Instruments::SetRoll(void)
{
	return m_dl->Set_Roll();
}
/*! \brief returns the roll in degrees -180 thru +180
\return \b float : returns the roll in degrees -180 thru +180

*/
float C_Instruments::GetRoll(void)
{
	return m_dl->Get_Roll();
}

/*! \brief query game and set private variable for pitch
\return \b boolean : returns whether the query to the game was successful.
*/
bool C_Instruments::SetPitch(void)
{
	return m_dl->Set_Pitch();
}
/*! \brief returns the pitch in degrees -90 thru +90
\return \b float : returns the roll in degrees -90 thru +90

*/
float C_Instruments::GetPitch(void)
{
	return m_dl->Get_Pitch();
}

/*! \brief query game and set private variable for fuel
\return \b boolean : returns whether the query to the game was successful.
*/
bool C_Instruments::SetFuel(void)
{
	return m_dl->Set_Fuel();
}
/*! \brief returns the pitch in degrees -90 thru +90
\return \b float : returns the roll in degrees -90 thru +90

*/
float C_Instruments::GetFuel(void)
{
	return m_dl->Get_Fuel();
}

/*! \brief query game and set ALL the private variables
\return \b boolean : returns whether the query to the game was successful.
*/
bool C_Instruments::SetAll(void)
{
	return m_dl->SetAllInstruments();
}
