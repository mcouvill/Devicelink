/*! \file Aircraft.cpp
	\brief The main source file for the Aircraft class
	\author Mike Couvillion
	\date 2004-2007 Copyright.
*/
#include "Aircraft.h"

using namespace std;

C_Aircraft::C_Aircraft(void)
{
	if (InitDeviceLink() == TRUE)
	{
		m_gear = new C_LandingGear(&m_dl);
		// since all the aircraft have at least one engine let's go ahead and
		//instantiate it.
		CreateEngine(ENGINE_ONE);
		CreateCockpit(0); // instantiate the pilot's cockpit
		m_inst = new C_Instruments(&m_dl);
		m_ctrl = new C_Controls(&m_dl);
		m_lights = new C_Lights(&m_dl);
		m_eng2 = NULL;
		m_eng3 = NULL;
		m_eng4 = NULL;
		m_weap1 = new C_Weapon(&m_dl, MG);
		m_weap2 = new C_Weapon(&m_dl, CANNON);
		m_weap3 = new C_Weapon(&m_dl, ROCKETS);
		m_weap4 = new C_Weapon(&m_dl, BOMBS);
		m_weap5 = new C_Weapon(&m_dl, MGCANNON);
		for (int i = 0; i < MAX_PITS; ++i)
		{
			m_pit[i] = NULL;
		}
	}
}
C_Aircraft::~C_Aircraft(void)
{
	delete m_gear;
	delete m_eng1;
	delete m_inst;
	delete m_ctrl;
	delete m_lights;
	if (m_eng2 != NULL)
	{
		delete m_eng2;
	}
	if (m_eng3 != NULL)
	{
		delete m_eng3;
	}
	if (m_eng4 != NULL)
	{
		delete m_eng4;
	}
	delete m_weap1;
	delete m_weap2;
	delete m_weap3;
	delete m_weap4;
	delete m_weap5;
	delete []*m_pit;
}
/*! \brief Initializes the aircrafts devicelink object
\return \b boolean
*/
bool C_Aircraft::InitDeviceLink(void)
{
	FILE *fp = NULL;
	int err = 0;
	fp = fopen("bbbr_debug.txt", "w");
	if (err != 0)
	{
		cout << "Cannot open config file.\n";
		exit(1);
	}
	return m_dl.Init();
}

/*! \brief returns the LandingGear object
\return \b LandingGear*
*/
C_LandingGear* C_Aircraft::Gear(void)
{
	return m_gear;
}

/*! \brief returns a pointer to the Engine object
\return \b Engine*
*/
C_Engine* C_Aircraft::Engine(const int eng_idx)
{
	switch (eng_idx)
	{
		case ENGINE_ONE:
			return m_eng1;
			break;
		case ENGINE_TWO:
			return m_eng2;
			break;
		case ENGINE_THREE:
			return m_eng3;
			break;
		case ENGINE_FOUR:
			return m_eng4;
			break;
		default:
			return m_eng1;
	}	
}
/*! \brief returns a pointer to the Cockpits object
\return \b Cockpits*
*/
C_Cockpits* C_Aircraft::Cockpits(const int pit_idx)
{
	return m_pit[pit_idx];
}
/*! \brief returns the Instruments object pointer

*/
C_Instruments* C_Aircraft::Instruments(void)
{
	return m_inst;
}

/* \brief tells whether passed in command has a valid Get
\param const char* code : the code being checked
\return \b boolean

*/
bool C_Aircraft::IsGetValid(const char* code)
{
	return m_dl.ValidGet(code);
}

/* \brief returns the number of engines the aircraft has
\return \b int : the number of engines

*/
int C_Aircraft::GetNumEngines(void)
{
	return m_dl.GetNumEngines();
}

/* \brief returns the number of cockpits the aircraft has
\return \b int : the number of cockpits

*/
int C_Aircraft::GetNumCockpits(void)
{
	return m_dl.GetNumOfCockpits();
}

/* \brief Gets the current DeviceLink version
\returns \b char* : pointer to the string holding the version

*/
char* C_Aircraft::GetDLVersion(void)
{
	bool flag = false;
	flag = m_dl.GetDLVersion(m_dl_ver, sizeof(m_dl_ver));
	if (true == flag)
	{
		return m_dl_ver;
	}
	return NULL;
}

/*! \brief retrieves the aircraft name
\return char*

*/
char * C_Aircraft::GetAircraftName(void)
{

bool flag = false;
flag = m_dl.GetAircraftID(m_ac_name, sizeof(m_ac_name));
	if (true == flag)
	{
		return m_ac_name;
	}
	return "Unknown Aircraft";
}

/*! \brief Instantiates the engine objects and assigns to pointers as needed
\param const int eng_idx : the engine index of the engine to create. 0 -- 3.
\return void

*/
void C_Aircraft::CreateEngine(const int eng_idx)
{
	switch (eng_idx)
	{
		case ENGINE_ONE:
			m_eng1 = new C_Engine(&m_dl,ENGINE_ONE);
			break;
		case ENGINE_TWO:
			m_eng2 = new C_Engine(&m_dl,ENGINE_TWO);
			break;
		case ENGINE_THREE:
			m_eng3 = new C_Engine(&m_dl, ENGINE_THREE);
			break;
		case ENGINE_FOUR:
			m_eng4 = new C_Engine(&m_dl, ENGINE_FOUR);
			break;
		default:
			break;
	}
}
/*! \brief Instantiates the cockpit object based on the index passed in and
assigns to pointers as needed
\param const int : Cockpit index
\return void;

*/
void C_Aircraft::CreateCockpit(int pit_idx)
{
	m_pit[pit_idx] = new C_Cockpits(&m_dl, pit_idx);
}