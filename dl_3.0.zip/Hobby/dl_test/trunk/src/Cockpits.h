/*! \file C_Cockpits.h
\brief Main header file for the C_Cockpits class
\author Mike Couvillion
\date Copyright 2004-2007

\note This code is free to use for free utilities. It is not free for commercial use.  
Not responsible for any errors. Use at your own risk. If you do use the code I ask you
give proper credit.
*/
#pragma once
#include "devicelink.h"

class C_Cockpits
{
	public:
		C_Cockpits(void);
		C_Cockpits(C_DeviceLink* dl, const int pit_idx);
		~C_Cockpits(void);
		bool OpenCanopy(void);
		bool CloseCanopy(void);
		bool Fire(void);
		bool CeaseFire(void);
	private:
		C_DeviceLink* m_dl;
		int getcanopy(void);
		bool togglecanopy(int i);
		int m_pitnum;
		bool togglefire(int i);
		bool getfire(void);

};
