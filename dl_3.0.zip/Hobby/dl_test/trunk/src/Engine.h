/*! \file Engine.h
	\brief The main header file for the Engine class
	\author Mike Couvillion
	\date 2004-2007 Copyright.
*/
#pragma once
#include "devicelink.h"

class C_Engine
	{
	public:
		C_Engine(void);
		C_Engine(C_DeviceLink* dl, int engidx);
		~C_Engine(void);
	private:
		C_DeviceLink* m_dl;
		int m_eng_idx; //!< identifies which engine this is. 0 is Eng 1 etc...
        int wep_state(void); //!< tracks current wep_state

	public:
		float GetRPM(void);
		float GetMani(void);
		float GetOilin(void);
		float GetOilout(void);
		float GetWater(void);
		float GetCyl(void);
		int GetNumMags(void);
		bool SetData(void);
		bool Start(void);
		bool Stop(void);
		void WEPOn(void);
		void WEPOff(void);
		bool SuperChargerNext(void);
		bool SuperChargerPrev(void);
		bool MagNext(void);
		bool MagPrev(void);
		bool FireExt(void);
		bool Feather(void);
	};
