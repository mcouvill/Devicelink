/*! \file Controls.cpp
\brief Main source file for the C_Controls class
\author Mike Couvillion
\date Copyright 2004-2007

\note This code is free to use for free utilities. It is not free for commercial use.  
Not responsible for any errors. Use at your own risk. If you do use the code I ask you
give proper credit.
*/
#include "Controls.h"

C_Controls::C_Controls(void)
: m_dl(NULL)
{
}
C_Controls::C_Controls(C_DeviceLink* dl)
: m_dl(dl)
{
}
C_Controls::~C_Controls(void)
{
}

/*! \brief sets the power
\param const int eng_idx : the engine to set the power -1.00 -- +1.00
\param float power_pos : the desired setting
\return \b boolean

\note You must Select the correct engine or it will default to the currently
selected engine.
*/
bool C_Controls::SetPower(const int eng_idx, float power_pos)
{
	return m_dl->Set_Power(eng_idx, power_pos);
}

/*! \brief sets the power
\param const int eng_idx : the engine to get the current power setting
\return \b float : current power setting -1.00 -- +1.00

\note You must Select the correct engine or it will default to the currently
selected engine.
*/
float C_Controls::GetPower(const int eng_idx)
{
	if (true == m_dl->Query_Power(eng_idx))
	{
		return m_dl->Get_Power(eng_idx);
	}
	return 0.00;
}
/*! \brief sets the flaps
\param float : flap_pos -- the desired flaps positon
\return \b float : current flaps setting -1.00 -- +1.00

*/
bool C_Controls::SetFlaps(float flap_pos)
{
	return m_dl->Set_Flaps(flap_pos);
}

/*! \brief sets the flaps
\return \b float : current flaps setting -1.00 -- +1.00

*/
float C_Controls::GetFlaps(void)
{
	if (true == m_dl->Query_Flaps())
	{
		return m_dl->Get_Flaps();
	}
	return 0.00;}

/*! \brief sets the ailerons
\param float : ail_pos
\return \b boolean : current ailerons setting -1.00 -- +1.00

*/
bool C_Controls::SetAileron(float ail_pos)
{
	return m_dl->Set_Aileron(ail_pos);
}

/*! \brief gets the ailerons
\return \b float : current ailerons setting -1.00 -- +1.00

*/
float C_Controls::GetAileron(void)
{
	if (true == m_dl->Query_Aileron())
	{
		return m_dl->Get_Aileron();
	}
	return 0.00;
}

/*! \brief sets the elevatorss
\param float : elev_pos
\return \b boolean : current elevators setting -1.00 -- +1.00

*/
bool C_Controls::SetElevator(float elev_pos)
{
	return m_dl->Set_Elevator(elev_pos);
}

/*! \brief gets the elevators
\return \b float : current elevators setting -1.00 -- +1.00

*/
float C_Controls::GetElevator(void)
{
	if (true == m_dl->Query_Elevator())
	{
		return m_dl->Get_Elevator();
	}
	return 0.00;
}

/*! \brief sets the rudder
\param float : rudder_pos
\return \b boolean : current rudder setting -1.00 -- +1.00

*/
bool C_Controls::SetRudder(float rudder_pos)
{
	return m_dl->Set_Rudder(rudder_pos);
}

/*! \brief gets the Rudder
\return \b float : current Rudder setting -1.00 -- +1.00

*/
float C_Controls::GetRudder(void)
{
	if (true == m_dl->Query_Rudder())
	{
		return m_dl->Get_Rudder();
	}
	return 0.00;
}

/*! \brief sets the ailerons trim
\param float : ail_pos_trim
\return \b boolean : current ailerons trim setting -1.00 -- +1.00

*/
bool C_Controls::SetAileronTrim(float ail_pos_trim)
{
	return m_dl->Set_AilTrim(ail_pos_trim);
}

/*! \brief gets the ailerons trim
\return \b float : current ailerons trim setting -1.00 -- +1.00

*/
float C_Controls::GetAileronTrim(void)
{
	if (true == m_dl->Query_AilTrim())
	{
		return m_dl->Get_AilTrim();
	}
	return 0.00;
}

/*! \brief sets the elevators trim
\param float : elev_pos_trim
\return \b boolean : current elevators trim setting -1.00 -- +1.00

*/
bool C_Controls::SetElevatorTrim(float elev_pos_trim)
{
	return m_dl->Set_ElvTrim(elev_pos_trim);
}

/*! \brief gets the elevator trim
\return \b float : current elevator trim setting -1.00 -- +1.00

*/
float C_Controls::GetElevatorTrim(void)
{
	if (true == m_dl->Query_ElvTrim())
	{
		return m_dl->Get_ElvTrim();
	}
	return 0.00;
}

/*! \brief sets the elevators trim
\param float : rudder_pos_trim
\return \b boolean : current elevators setting -1.00 -- +1.00

*/
bool C_Controls::SetRudderTrim(float rudder_pos_trim)
{
	return m_dl->Set_RudTrim(rudder_pos_trim);
}

/*! \brief gets the Rudder trim
\return \b float : current Rudder trim setting -1.00 -- +1.00

*/
float C_Controls::GetRudderTrim(void)
{
	if (true == m_dl->Query_RudTrim())
	{
		return m_dl->Get_RudTrim();
	}
	return 0.00;
}

/*! \brief toggles the state of the airbrake
\return \b boolean
*/
bool C_Controls::togglelvlstab(int i)
{
	if (i == getlvlstab())
	{
		return m_dl->Set_LvlStab();
	}
	return false;
}

/*! \brief Sets the Level Stabilizer On
\return \b boolean
*/
bool C_Controls::LvlStabOn(void)
{
	return togglelvlstab(0);
}

/*! \brief sets the Level Stabilizer off
\return \b boolean
*/
bool C_Controls::LvlStabOff(void)
{
	return togglelvlstab(1);
}

/*! \brief gets the Level Stabilizer 
\return \b int : 1 means it is engaged and 0 it is not.
*/
int C_Controls::getlvlstab(void)
{
	if (true == m_dl->Query_LvlStab())
	{
		return m_dl->Get_LvlStab();
	}
	return 0;
}

/*! \brief gets the current state of the airbrake
\return \b integer : returns a 1 if in use and 0 if not

*/
int C_Controls::getairbrake(void)
{
	if (true == m_dl->Query_Airbrakes())
	{
		return m_dl->Get_Airbrakes();
	}
	return 0;
}

/*! \brief toggles the state of the airbrake
\return \b boolean
*/
bool C_Controls::toggleairbrake(int i)
{
	if (i == getairbrake())
	{
		return m_dl->Set_Airbrakes();
	}
	return true;
}
/*! \brief deploy the airbrake
\return \b boolean
*/
bool C_Controls::DeployAirbrake(void)
{
	return toggleairbrake(0);
}

/*! \brief retract the airbrake
\return \b boolean
*/
bool C_Controls::RetractAirbrake(void)
{
	return toggleairbrake(1);
}

/*! \brief increment the cowl flaps position
\return \b boolean
*/
bool C_Controls::CowlFlaps(void)
{
	return m_dl->Set_CowlFlaps();
}